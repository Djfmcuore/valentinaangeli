// ============================================================
// CONFIGURAZIONE — modifica solo queste due righe
// ============================================================
// GITHUB_OWNER = il tuo username GitHub (es. "filippo123")
// GITHUB_REPO  = il nome del repository dove hai caricato questo sito
// Il ramo usato è "main" (se il tuo repo usa "master", cambia anche BRANCH)
// ============================================================
const CONFIG = {
  GITHUB_OWNER: "Djfmcuore",
  GITHUB_REPO: "valentinaangeli",
  BRANCH: "main",
};
