// ============================================================
// STATO
// ============================================================
let GH_TOKEN = null;
let manifestSha = null; // sha del file gallery-manifest.json, serve per aggiornarlo

const API_BASE = () => `https://api.github.com/repos/${CONFIG.GITHUB_OWNER}/${CONFIG.GITHUB_REPO}`;

function setStatus(elId, message, type) {
  const el = document.getElementById(elId);
  el.textContent = message;
  el.className = "status " + type;
}

function ghHeaders() {
  return {
    Authorization: `Bearer ${GH_TOKEN}`,
    Accept: "application/vnd.github+json",
  };
}

// ============================================================
// 1. CONNESSIONE / VERIFICA TOKEN
// ============================================================
document.getElementById("connect-btn").addEventListener("click", async () => {
  const token = document.getElementById("token-input").value.trim();
  if (!token) {
    setStatus("auth-status", "Incolla prima il token.", "err");
    return;
  }
  if (CONFIG.GITHUB_OWNER === "INSERISCI-USERNAME") {
    setStatus("auth-status", "Configura prima js/config.js con il tuo username e repo.", "err");
    return;
  }

  setStatus("auth-status", "Verifica in corso...", "loading");
  GH_TOKEN = token;

  try {
    const res = await fetch(API_BASE(), { headers: ghHeaders() });
    if (!res.ok) throw new Error("Token non valido o repository non accessibile.");
    setStatus("auth-status", "Connesso correttamente ✔", "ok");
    document.getElementById("upload-card").classList.remove("locked");
    document.getElementById("list-card").classList.remove("locked");
    await loadPhotoList();
  } catch (err) {
    GH_TOKEN = null;
    setStatus("auth-status", "Errore: " + err.message, "err");
  }
});

// ============================================================
// HELPERS API
// ============================================================
async function getManifest() {
  const res = await fetch(`${API_BASE()}/contents/images/gallery-manifest.json`, { headers: ghHeaders() });
  if (!res.ok) throw new Error("Impossibile leggere il manifest foto.");
  const data = await res.json();
  manifestSha = data.sha;
  const content = JSON.parse(atob(data.content));
  return content;
}

async function putManifest(newContent, message) {
  const res = await fetch(`${API_BASE()}/contents/images/gallery-manifest.json`, {
    method: "PUT",
    headers: ghHeaders(),
    body: JSON.stringify({
      message,
      content: btoa(unescape(encodeURIComponent(JSON.stringify(newContent, null, 2)))),
      sha: manifestSha,
      branch: CONFIG.BRANCH,
    }),
  });
  if (!res.ok) throw new Error("Impossibile aggiornare il manifest.");
  const data = await res.json();
  manifestSha = data.content.sha;
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(",")[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function slugify(name) {
  return name
    .toLowerCase()
    .replace(/\.[^/.]+$/, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

// ============================================================
// 2. UPLOAD FOTO
// ============================================================
document.getElementById("upload-btn").addEventListener("click", async () => {
  const fileInput = document.getElementById("file-input");
  const captionInput = document.getElementById("caption-input");
  const file = fileInput.files[0];

  if (!file) {
    setStatus("upload-status", "Seleziona prima un file.", "err");
    return;
  }

  setStatus("upload-status", "Caricamento in corso...", "loading");

  try {
    const base64 = await fileToBase64(file);
    const ext = file.name.split(".").pop();
    const filename = `${Date.now()}-${slugify(file.name)}.${ext}`;

    // 1. carica il file immagine
    const uploadRes = await fetch(`${API_BASE()}/contents/images/gallery/${filename}`, {
      method: "PUT",
      headers: ghHeaders(),
      body: JSON.stringify({
        message: `Aggiunge foto ${filename}`,
        content: base64,
        branch: CONFIG.BRANCH,
      }),
    });
    if (!uploadRes.ok) throw new Error("Errore durante l'upload dell'immagine.");

    // 2. aggiorna il manifest
    const manifest = await getManifest();
    manifest.photos.push({ filename, caption: captionInput.value.trim() });
    await putManifest(manifest, `Aggiunge ${filename} alla galleria`);

    setStatus("upload-status", "Foto caricata! Sarà visibile sul sito entro un minuto.", "ok");
    fileInput.value = "";
    captionInput.value = "";
    await loadPhotoList();
  } catch (err) {
    setStatus("upload-status", "Errore: " + err.message, "err");
  }
});

// ============================================================
// 3. LISTA + ELIMINAZIONE FOTO
// ============================================================
async function loadPhotoList() {
  const listEl = document.getElementById("photo-list");
  setStatus("list-status", "Carico l'elenco...", "loading");

  try {
    const manifest = await getManifest();
    listEl.innerHTML = "";

    if (manifest.photos.length === 0) {
      setStatus("list-status", "Nessuna foto caricata ancora.", "ok");
      return;
    }
    setStatus("list-status", "", "");
    document.getElementById("list-status").className = "status";

    manifest.photos.forEach((photo) => {
      const item = document.createElement("div");
      item.className = "photo-item";
      item.innerHTML = `
        <img src="https://cdn.jsdelivr.net/gh/${CONFIG.GITHUB_OWNER}/${CONFIG.GITHUB_REPO}@${CONFIG.BRANCH}/images/gallery/${photo.filename}" alt="${photo.caption || ""}">
        <button data-filename="${photo.filename}">Elimina</button>
      `;
      listEl.appendChild(item);
    });

    listEl.querySelectorAll("button").forEach((btn) => {
      btn.addEventListener("click", () => deletePhoto(btn.dataset.filename));
    });
  } catch (err) {
    setStatus("list-status", "Errore: " + err.message, "err");
  }
}

async function deletePhoto(filename) {
  if (!confirm(`Eliminare la foto "${filename}"?`)) return;
  setStatus("list-status", "Eliminazione in corso...", "loading");

  try {
    // 1. trova sha del file immagine per poterlo eliminare
    const fileRes = await fetch(`${API_BASE()}/contents/images/gallery/${filename}`, { headers: ghHeaders() });
    if (!fileRes.ok) throw new Error("File non trovato su GitHub.");
    const fileData = await fileRes.json();

    // 2. elimina il file immagine
    const delRes = await fetch(`${API_BASE()}/contents/images/gallery/${filename}`, {
      method: "DELETE",
      headers: ghHeaders(),
      body: JSON.stringify({
        message: `Rimuove foto ${filename}`,
        sha: fileData.sha,
        branch: CONFIG.BRANCH,
      }),
    });
    if (!delRes.ok) throw new Error("Impossibile eliminare l'immagine.");

    // 3. aggiorna il manifest
    const manifest = await getManifest();
    manifest.photos = manifest.photos.filter((p) => p.filename !== filename);
    await putManifest(manifest, `Rimuove ${filename} dalla galleria`);

    setStatus("list-status", "Foto eliminata.", "ok");
    await loadPhotoList();
  } catch (err) {
    setStatus("list-status", "Errore: " + err.message, "err");
  }
}
