// ============================================================
// NAV — ombra on scroll
// ============================================================
const nav = document.getElementById("nav");
window.addEventListener("scroll", () => {
  nav.classList.toggle("scrolled", window.scrollY > 20);
});

// ============================================================
// REVEAL ON SCROLL
// ============================================================
const revealEls = document.querySelectorAll(".reveal, .service-card");
const io = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add("in-view");
      io.unobserve(entry.target);
    }
  });
}, { threshold: 0.15 });
revealEls.forEach((el) => io.observe(el));

// ============================================================
// GALLERIA — carica le foto dal manifest su GitHub (via jsDelivr CDN)
// ============================================================
async function loadGallery() {
  const grid = document.getElementById("gallery-grid");
  const { GITHUB_OWNER, GITHUB_REPO, BRANCH } = CONFIG;

  if (GITHUB_OWNER === "INSERISCI-USERNAME") {
    // Config non ancora impostata: lascia il placeholder
    return;
  }

  const manifestUrl = `https://cdn.jsdelivr.net/gh/${GITHUB_OWNER}/${GITHUB_REPO}@${BRANCH}/images/gallery-manifest.json`;

  try {
    const res = await fetch(manifestUrl, { cache: "no-store" });
    if (!res.ok) throw new Error("Manifest non trovato");
    const data = await res.json();
    const photos = data.photos || [];

    if (photos.length === 0) return; // resta il messaggio "presto qui"

    grid.innerHTML = "";
    photos.forEach((photo) => {
      const img = document.createElement("img");
      img.src = `https://cdn.jsdelivr.net/gh/${GITHUB_OWNER}/${GITHUB_REPO}@${BRANCH}/images/gallery/${photo.filename}`;
      img.alt = photo.caption || "Foto dello studio";
      img.loading = "lazy";
      grid.appendChild(img);
    });
  } catch (err) {
    console.warn("Galleria: impossibile caricare le foto ancora.", err);
  }
}

loadGallery();
